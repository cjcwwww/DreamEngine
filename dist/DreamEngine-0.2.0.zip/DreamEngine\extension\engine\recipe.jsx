// ============================================================
// recipe.jsx —— 演示配方与启发式兜底
//
// 分两层：
//   1. 显式配方（RECIPES）：已经目视确认过"看得出名堂"的效果，按 matchName 写死参数
//   2. 启发式兜底（applyHeuristics）：没有配方的效果，按 propertyValueType 生成演示值
//
// 启发式的设计原则是「保守」而不是「激进」：
//   AE 的参数名与语义千差万别，把每个数值属性都拉到中值会让大量效果变糊、
//   变黑或直接看不出原貌。因此只处理四类语义明确的属性，并且每个效果
//   最多写 MAX_WRITES 次，宁可看着"变化不明显"也不要把效果改坏。
//
// 语法：ES3 only。
// ============================================================

var AEV_Recipe = (function () {
    var MAX_WRITES = 6;
    var MAX_DEPTH = 3;
    var PRESENTATION_TIME_RATIO = 0.5;
    /** 配方版本：改配方语义时 +1，所有缓存随之失效 */
    var RECIPE_VERSION = 5;

    /** 表达式控件族与音频族的分类名（中英文都要认，汉化版分类名是中文） */
    var NO_PREVIEW_CATEGORIES = [
        "expression controls", "表达式控制",
        "audio", "音频"
    ];

    /** 显式配方：matchName -> [{names:[...], value:...}]
     *  参数名以 tools/dump_param_trees.jsx 从本机导出的真实名字为准（中文界面下是中文），
     *  同时并列英文名以兼容英文版 AE。不是猜的。
     */
    var RECIPES = {
        "ADBE Gaussian Blur 2": [{ names: ["模糊度", "Blurriness"], value: 12 }],
        "ADBE Box Blur2": [
            { names: ["模糊半径", "Blur Radius"], value: 12 },
            { names: ["迭代", "Iterations"], value: 3 }
        ],
        "ADBE Radial Blur": [
            { names: ["数量", "Amount"], value: 60 },
            { names: ["类型", "Type"], value: 2 }
        ],
        "ADBE Sharpen": [{ names: ["锐化量", "Sharpen Amount"], value: 60 }],
        "ADBE Unsharp Mask2": [
            { names: ["数量", "Amount"], value: 150 },
            { names: ["半径", "Radius"], value: 8 }
        ],
        "ADBE Brightness & Contrast 2": [
            { names: ["亮度", "Brightness"], value: 10 },
            { names: ["对比度", "Contrast"], value: 30 }
        ],
        "ADBE HUE SATURATION": [{ names: ["主饱和度", "Master Saturation"], value: 60 }],
        "ADBE Tint": [{ names: ["着色数量", "Amount to Tint"], value: 100 }],
        "ADBE Easy Levels2": [{ names: ["灰度系数", "Gamma"], value: 1.6 }],
        "ADBE Mosaic": [
            { names: ["水平块", "Horizontal Blocks"], value: 18 },
            { names: ["垂直块", "Vertical Blocks"], value: 18 }
        ],
        "ADBE Glo2": [
            { names: ["发光半径", "Glow Radius"], value: 30 },
            { names: ["发光强度", "Glow Intensity"], value: 1.5 }
        ],
        "ADBE Turbulent Displace": [
            { names: ["数量", "Amount"], value: 60 },
            { names: ["大小", "Size"], value: 40 }
        ],
        "ADBE Wave Warp": [
            { names: ["波形高度", "Wave Height"], value: 40 },
            { names: ["波形宽度", "Wave Width"], value: 60 }
        ],
        "ADBE Ripple": [
            { names: ["半径", "Radius"], value: 60 },
            { names: ["波形高度", "Wave Height"], value: 30 }
        ],
        "ADBE Bulge": [{ names: ["凸出高度", "Bulge Height"], value: 1.5 }],
        "ADBE Twirl": [{ names: ["角度", "Angle"], value: 90 }],
        "ADBE Drop Shadow": [
            { names: ["距离", "Distance"], value: 12 },
            { names: ["柔和度", "Softness"], value: 20 },
            { names: ["不透明度", "Opacity"], value: 200 }
        ],
        "ADBE Bevel Alpha": [
            { names: ["边缘厚度", "Edge Thickness"], value: 8 },
            { names: ["灯光强度", "Light Intensity"], value: 0.6 }
        ],
        "CC Radial Fast Blur": [{ names: ["Amount", "数量"], value: 60 }],
        "CC Lens": [{ names: ["Size", "大小"], value: 145 }],
        "CC Bender": [{ names: ["Amount", "数量"], value: 60 }],
        "CC Burn Film": [{ names: ["Burn", "燃烧"], value: 50 }],

        // ---- 第二批：CC 系列（参数名由 dump_param_trees 第二批实测导出）----
        // 注意：CC 是第三方插件风格，即使中文界面，参数名仍是英文。
        "CC Radial Blur": [
            { names: ["Amount"], value: 45 },
            { names: ["Type"], value: 2 }
        ],
        "CC Vector Blur": [{ names: ["Amount"], value: 160 }],
        "CC Color Offset": [
            { names: ["Red Phase"], value: 80 },
            { names: ["Blue Phase"], value: -60 }
        ],
        "CC Toner": [{ names: ["Blend w. Original"], value: 0 }],
        "CC Overbrights": [{ names: ["Channel"], value: 1 }],
        "CC Threshold": [
            { names: ["Blend w. Original"], value: 0 },
            { names: ["Threshold"], value: 0.45 }
        ],
        "CC Threshold RGB": [
            { names: ["Red Threshold"], value: 0.55 },
            { names: ["Green Threshold"], value: 0.42 },
            { names: ["Blue Threshold"], value: 0.3 }
        ],
        "CC Kaleida": [
            { names: ["Size"], value: 130 },
            { names: ["Mirroring"], value: 3 }
        ],
        "CC Glass": [
            { names: ["Height"], value: 60 },
            { names: ["Displacement"], value: 60 }
        ],
        "CC Plastic": [{ names: ["Height"], value: 60 }],
        "CC RepeTile": [
            { names: ["Expand Right"], value: 140 },
            { names: ["Expand Down"], value: 140 }
        ],
        "CC Bend It": [{ names: ["Bend"], value: 90 }],
        "CC Blobbylize": [{ names: ["Softness"], value: 60 }],
        "CC Flo Motion": [{ names: ["Amount 1"], value: 320 }],
        "CC Griddler": [
            { names: ["Horizontal Scale"], value: 700 },
            { names: ["Vertical Scale"], value: 700 },
            { names: ["Tile Size"], value: 30 }
        ],
        "CC Slant": [{ names: ["Slant"], value: 70 }],
        "CC Split": [{ names: ["Split"], value: 90 }],
        "CC Tiler": [{ names: ["Scale"], value: 0.35 }],
        "CC Light Burst 2.5": [
            { names: ["Intensity"], value: 140 },
            { names: ["Ray Length"], value: 160 }
        ],
        "CC Light Rays": [
            { names: ["Intensity"], value: 130 },
            { names: ["Radius"], value: 240 }
        ],
        "CC Light Sweep": [
            { names: ["Width"], value: 280 },
            { names: ["Sweep Intensity"], value: 130 }
        ],
        "CC Scale Wipe": [{ names: ["Stretch"], value: 70 }],
        "CC Grid Wipe": [
            { names: ["Completion"], value: 0.5 },
            { names: ["Tiles"], value: 6 }
        ],
        "CC Star Burst": [{ names: ["Scatter"], value: 180 }],
        "CC Scatterize": [{ names: ["Scatter"], value: 120 }],
        "CC Cylinder": [{ names: ["Radius (%)"], value: 70 }],
        "CC Sphere": [{ names: ["Radius"], value: 140 }],
        "CC Glue Gun": [
            { names: ["Stroke Width"], value: 40 },
            { names: ["Density"], value: 60 }
        ],
        "CC Page Turn": [{ names: ["Fold Radius"], value: 60 }],

        // ---- 两层输入 / 调整层（新场景）----
        "ADBE Displacement Map": [
            { names: ["最大水平置换"], value: 90 },
            { names: ["最大垂直置换"], value: 90 }
        ],
        "ADBE Compound Blur": [{ names: ["最大模糊"], value: 45 }],
        "ADBE Set Matte3": [{ names: ["用于遮罩"], value: 4 }],
        "ADBE Fill": [
            { names: ["颜色"], value: [0.16, 0.52, 0.82] },
            { names: ["不透明度"], value: 0.55 }
        ],
        "ADBE Ramp": [
            { names: ["起始颜色"], value: [0.08, 0.18, 0.42] },
            { names: ["结束颜色"], value: [0.95, 0.55, 0.2] }
        ],
        "ADBE Gradient Wipe": [
            { names: ["过渡完成"], value: 0.5 },
            { names: ["过渡柔和度"], value: 0.3 }
        ],
        "ADBE 4ColorGradient": [
            { names: ["不透明度"], value: 70 },
            { names: ["颜色 1"], value: [0.1, 0.3, 0.6] },
            { names: ["颜色 2"], value: [0.9, 0.4, 0.2] }
        ]
    };

    /**
     * 替代方案：某些效果不能真渲（AE 会挂死），但用户仍希望预览墙上有一张
     * 能代表它的卡片。用一个观感相近的安全效果代替。
     *
     * ADBE Lumetri（Lumetri 颜色）实测一渲染就挂死，AE 直接未响应。
     * 它的视觉本质是「色彩科学 + 饱和度」，所以用饱和度调整来代表。
     */
    var SURROGATES = {
        "ADBE Lumetri": {
            effect: "ADBE HUE SATURATION",
            steps: [{ names: ["主饱和度", "Master Saturation"], value: 60 }],
            reason: "Lumetri 渲染挂死，用饱和度调整代表"
        }
    };

    /** 实际要挂到合成上的效果名（有替代方案就用替代的） */
    function effectNameFor(matchName) {
        var s = SURROGATES[matchName];
        return s ? s.effect : matchName;
    }

    /** 实际要写的参数步骤（有替代方案就用替代的） */
    function stepsFor(matchName) {
        var s = SURROGATES[matchName];
        if (s) return s.steps;
        return RECIPES[matchName] || null;
    }

    function isSurrogate(matchName) {
        return SURROGATES[matchName] ? true : false;
    }

    function lower(value) {
        return String(value === undefined || value === null ? "" : value).toLowerCase();
    }

    /** 表达式控件 / 音频族不渲图（设计文档 §4.3 的 no-preview 场景） */
    function isNoPreview(category) {
        var cat = lower(category);
        for (var i = 0; i < NO_PREVIEW_CATEGORIES.length; i++) {
            if (cat === NO_PREVIEW_CATEGORIES[i]) return true;
        }
        return false;
    }

    /** 必须有第二图层才成立的效果（置换图 / 复合模糊 / 设置遮罩 / 图层输入类）。
     *  名单来自本机实测：这些效果在单层合成里"加上了但画面不变"。
     */
    var TWO_LAYER_PATTERNS = [
        "displacement map", "compound blur", "set matte",
        "calculations", "compound arithmetic", "arithmetic",
        "time displacement", "gradient wipe",
        "cc composite", "cc vector blur", "cc mr. smoothie",
        "cc image wipe", "cc warpomatic"
    ];

    /** 需要下层背景的效果：自身只生成部分内容，留白处要露出下面的画面 */
    var ADJUSTMENT_PATTERNS = [
        "adbe fill", "adbe ramp", "4colorgradient", "scribble fill", "eyedropper fill"
    ];

    /**
     * 推断场景类型（设计文档 §4.3 的八类枚举）。
     * 只靠 matchName 与可选 category 判断——previewgen 手里只有 matchName，
     * 所以判断规则必须能在没有分类信息时也站得住。
     */
    function sceneFor(matchName, category) {
        if (isNoPreview(category)) return "no-preview";
        var cat = lower(category);
        var mn = lower(matchName);

        if (cat === "text" || cat === "文本") return "text";
        if (/(^|\W)(text|numbers|typewriter|word)/.test(mn)) return "text";
        if (cat === "3d channel" || cat === "3d 通道") return "3d-camera";

        // 两层输入要排在别的规则前面：这些效果单层时完全看不出变化
        for (var i = 0; i < TWO_LAYER_PATTERNS.length; i++) {
            if (mn.indexOf(TWO_LAYER_PATTERNS[i]) >= 0) return "two-layer-input";
        }
        for (var j = 0; j < ADJUSTMENT_PATTERNS.length; j++) {
            if (mn.indexOf(ADJUSTMENT_PATTERNS[j]) >= 0) return "adjustment";
        }

        if (/stroke|trace|outline|wireframe/.test(mn)) return "shape-mask";
        if (/solid|background/.test(mn)) return "solid-2d";
        return "footage-2d";
    }

    /**
     * 场景 → 临时合成的搭法。
     *   base       效果作用的那一层用哪种素材
     *   needBg     下面垫一层背景（调整层类：留白处要露出下面的画面）
     *   needSource 再插一层高对比图案当第二输入（两层输入类）
     *
     * 图层顺序（AE 里 1 是最上）：[effect(base), pattern, bg]
     * 所以第二输入一律绑定到第 2 层。
     */
    var LAYOUTS = {
        "footage-2d": { base: "photo", needBg: false, needSource: false },
        "solid-2d": { base: "solid", needBg: false, needSource: false },
        "text": { base: "text", needBg: false, needSource: false },
        "shape-mask": { base: "shape", needBg: false, needSource: false },
        "adjustment": { base: "photo", needBg: true, needSource: false },
        "two-layer-input": { base: "photo", needBg: true, needSource: true },
        "3d-camera": { base: "photo", needBg: false, needSource: false }
    };

    function layoutFor(scene) {
        var layout = LAYOUTS[scene];
        if (!layout) return { base: "photo", needBg: false, needSource: false };
        return { base: layout.base, needBg: layout.needBg, needSource: layout.needSource };
    }

    /** 场景类型 → 标准素材类型（assets.jsx 的 kind），保留给只需要素材类型的调用方 */
    function assetKindFor(scene) {
        return layoutFor(scene).base;
    }

    /** djb2 短哈希，用于缓存键 */
    function hashString(text) {
        var hash = 5381;
        var value = String(text);
        for (var i = 0; i < value.length; i++) {
            hash = ((hash << 5) + hash + value.charCodeAt(i)) & 0x7fffffff;
        }
        return hash.toString(36);
    }

    /**
     * 缓存指纹（设计文档 §4.5）：
     *   hash(matchName + recipeVersion + assetFingerprint + tileSize + frameCount)
     * AE 版本号刻意不参与——否则每次升级都会触发全量重渲。
     */
    function cacheKey(matchName, assetFingerprint, tileSize, frameCount) {
        return hashString([
            matchName,
            RECIPE_VERSION,
            assetFingerprint || "na",
            tileSize || 0,
            frameCount || 0
        ].join("|"));
    }

    /** 展示时点：取合成中点，避开首帧尚未成形的效果 */
    function presentationTime(comp) {
        try {
            return comp.duration * PRESENTATION_TIME_RATIO;
        } catch (e) {
            return 0;
        }
    }

    /** 纯函数：给定属性类型与取值范围，返回启发式演示值。
     *  返回 undefined 表示"这个属性不动"，调用方必须跳过。
     *  kind: "color" | "checkbox" | "oneD" | "other"
     *
     *  ⚠️ TwoD 一律不碰（设计文档 §4.3 原本要求给"中心+偏移"，已按实测推翻）：
     *  AE 2021 上 CC 系列的 Center 等 Point 控件是 0–1 归一化坐标，赋像素值
     *  [128,128] 会触发 AE 内部脚本异常
     *    "After Effects错误: Line 1849: var center = cs.convertPoint([0.5, 0.5"
     *  而整网批量渲染是一损俱损的——一个格子报错会让整张网失败。
     *  位置类参数保持效果默认值，视觉上可能"看不出偏移"，但不会崩。
     */
    function heuristicValue(kind, minValue, maxValue, cellSize) {
        if (kind === "color") return [0.9, 0.35, 0.2];
        if (kind === "checkbox") return true;
        if (kind === "oneD") {
            if (minValue === null || minValue === undefined) return undefined;
            if (maxValue === null || maxValue === undefined) return undefined;
            return (Number(minValue) + Number(maxValue)) / 2;
        }
        return undefined;
    }

    /** 把 AE 属性的 propertyValueType 归一成上面四种 kind 之一 */
    function kindOf(prop) {
        var type = null;
        try {
            type = String(prop.propertyValueType);
        } catch (e) {
            return "other";
        }
        // PropertyValueType 的字符串化结果在不同版本可能是数字或枚举名
        if (type === "COLOR" || type === String(PropertyValueType.COLOR)) return "color";
        if (type === "CHECKBOX" || type === String(PropertyValueType.CHECKBOX)) return "checkbox";
        // TWO_D / TWO_D_SPATIAL 故意归为 other：位置类参数的单位在不同效果里
        // 可能是像素也可能是 0–1 归一化，统一赋值会踩到 AE 内部脚本异常。
        if (type === "OneD" || type === "ONE_D" || type === String(PropertyValueType.OneD)) return "oneD";
        return "other";
    }

    function setIfWritable(prop, value) {
        if (value === undefined) return false;
        try {
            prop.setValue(value);
            return true;
        } catch (e) {
            return false;
        }
    }

    function findByName(group, names) {
        var count = 0;
        try {
            count = group.numProperties;
        } catch (e) {
            return null;
        }
        for (var i = 1; i <= count; i++) {
            var prop = null;
            try {
                prop = group.property(i);
            } catch (e2) {
                continue;
            }
            if (!prop || !prop.name) continue;
            var name = String(prop.name);
            for (var n = 0; n < names.length; n++) {
                if (name === names[n]) return prop;
            }
        }
        return null;
    }

    /** 套显式配方；返回写入次数，0 表示该效果没有配方 */
    function applyRecipe(effectGroup, matchName) {
        var steps = stepsFor(matchName);
        if (!steps) return 0;
        var writes = 0;
        for (var i = 0; i < steps.length; i++) {
            var prop = findByName(effectGroup, steps[i].names);
            if (prop && setIfWritable(prop, steps[i].value)) writes++;
        }
        return writes;
    }

    /** 启发式兜底；返回写入次数 */
    function applyHeuristics(effectGroup, cellSize) {
        var budget = MAX_WRITES;
        var writes = 0;

        function walk(group, depth) {
            if (depth > MAX_DEPTH || writes >= budget) return;
            var count = 0;
            try {
                count = group.numProperties;
            } catch (e) {
                return;
            }
            for (var i = 1; i <= count && writes < budget; i++) {
                var prop = null;
                try {
                    prop = group.property(i);
                } catch (e2) {
                    continue;
                }
                if (!prop) continue;

                var childCount = 0;
                try {
                    childCount = prop.numProperties;
                } catch (e3) {
                    childCount = 0;
                }
                if (childCount && childCount > 0) {
                    walk(prop, depth + 1);
                    continue;
                }

                var kind = kindOf(prop);
                if (kind === "other") continue;

                var minValue = null;
                var maxValue = null;
                try {
                    if (prop.hasMin) minValue = prop.minValue;
                    if (prop.hasMax) maxValue = prop.maxValue;
                } catch (e4) {}

                var value = heuristicValue(kind, minValue, maxValue, cellSize);
                if (setIfWritable(prop, value)) writes++;
            }
        }

        walk(effectGroup, 0);
        return writes;
    }

    /**
     * 给配方的主参数打关键帧，让预览「动起来」。
     *
     * 为什么需要：AE 效果默认不随时间变化——不设关键帧的话，
     * 6 帧渲染出来逐像素相同，缩略图轮播等于静止画面（实测 60 条里 59 条如此）。
     * 这里把主参数从 0 渐变到配方值，于是缩略图展示的是「效果逐渐起作用」，
     * 既能看出动，也能看出这个效果到底改变了什么。
     *
     * 只对数值型参数生效；颜色、位置类不参与（颜色渐变会变成黑场，位置类单位不统一）。
     * 返回是否成功打上关键帧。
     */
    function animate(effectGroup, matchName, durationSeconds) {
        var steps = stepsFor(matchName);
        if (!steps || !steps.length) return false;

        var prop = null;
        var target = null;
        for (var i = 0; i < steps.length; i++) {
            var candidate = findByName(effectGroup, steps[i].names);
            if (!candidate) continue;
            var type = kindOf(candidate);
            // 只处理一维数值：颜色渐变到 0 会变成黑场，位置类语义不统一
            if (type !== "oneD") continue;
            prop = candidate;
            target = steps[i].value;
            break;
        }
        if (!prop) return false;

        var start = 0;
        try {
            if (target === 0) {
                // 目标值是 0（常见于「与原始图像混合」这类 0=满效果的参数）时，
                // 0→0 等于没动画。此时从一个小非零值起步，动画方向是「效果退场」。
                var maxValue = prop.hasMax ? Number(prop.maxValue) : 1;
                start = maxValue > 0 ? Math.min(maxValue, 10) : 1;
            } else if (prop.hasMin) {
                var minValue = Number(prop.minValue);
                // 有些参数 0 不合法（最小值是 1 之类），那就从最小值起步
                if (minValue > 0 && minValue < Number(target)) start = minValue;
            }
        } catch (e) {}

        var end = Number(durationSeconds);
        if (!end || end <= 0) return false;
        try {
            prop.setValueAtTime(0, start);
            prop.setValueAtTime(end, target);
            return true;
        } catch (e2) {
            return false;
        }
    }

    /**
     * 给任意效果的主数值参数打关键帧（不依赖显式配方）。
     *
     * 背景：六成以上的效果没有显式配方，走的是启发式赋值。
     * 它们同样需要动起来——否则缩略图是静止的，看不出效果在做什么。
     * 这里取启发式写过的第一个一维数值参数，从 0 渐变到它当前的取值。
     *
     * 颜色与位置类一律跳过：颜色渐变到 0 会变成黑场，位置类单位不统一。
     */
    function animateAny(effectGroup, durationSeconds) {
        var end = Number(durationSeconds);
        if (!end || end <= 0) return false;

        // 选参数：取「范围最大」的一维数值属性。
        // 直觉上第一个数值参数最好，但实测里第一个常常是下拉项
        // （通道、场景检测、运算类型），改了画面没反应。
        // 范围最大的那个才是真正有表现力的滑杆。
        var best = null;
        var bestMax = -1;
        function walk(group, depth) {
            if (depth > MAX_DEPTH) return;
            var count = 0;
            try {
                count = group.numProperties;
            } catch (e) {
                return;
            }
            for (var i = 1; i <= count; i++) {
                var prop = null;
                try {
                    prop = group.property(i);
                } catch (e2) {
                    continue;
                }
                if (!prop) continue;
                var childCount = 0;
                try {
                    childCount = prop.numProperties;
                } catch (e3) {
                    childCount = 0;
                }
                if (childCount && childCount > 0) {
                    walk(prop, depth + 1);
                    continue;
                }
                if (kindOf(prop) !== "oneD") continue;
                var maxValue = 0;
                try {
                    if (prop.hasMax) maxValue = Number(prop.maxValue);
                } catch (e4) {}
                // 范围小于 5 的是下拉/枚举，改了也没画面变化
                if (maxValue < 5) continue;
                if (maxValue > bestMax) {
                    bestMax = maxValue;
                    best = prop;
                }
            }
        }
        walk(effectGroup, 0);
        if (!best) return false;

        var target = null;
        try {
            target = Number(best.value);
        } catch (e5) {
            return false;
        }
        if (isNaN(target)) return false;

        var start = 0;
        if (target === 0) {
            start = bestMax > 0 ? Math.min(bestMax, 10) : 1;
        } else {
            try {
                if (best.hasMin) {
                    var minValue = Number(best.minValue);
                    if (minValue > 0 && minValue < target) start = minValue;
                }
            } catch (e6) {}
            if (target === start) return false;
        }

        try {
            best.setValueAtTime(0, start);
            best.setValueAtTime(end, target);
            return true;
        } catch (e7) {
            return false;
        }
    }

    /** 统一入口：有配方走配方，没有就走启发式 */
    function apply(effectGroup, matchName, cellSize) {
        var explicitWrites = applyRecipe(effectGroup, matchName);
        if (explicitWrites > 0) {
            return { mode: "recipe", writes: explicitWrites };
        }
        var heuristicWrites = applyHeuristics(effectGroup, cellSize);
        return { mode: heuristicWrites > 0 ? "heuristic" : "none", writes: heuristicWrites };
    }

    function isLayerIndexProp(prop) {
        try {
            return String(prop.propertyValueType) === String(PropertyValueType.LAYER_INDEX);
        } catch (e) {
            return false;
        }
    }

    /**
     * 把效果里的「图层」选择器绑到指定图层序号。
     *
     * 为什么需要：置换图、复合模糊、设置遮罩这类两层输入效果，图层选择器默认是
     * 「无」，即使临时合成里摆了两层也不会自己接上，画面就完全没有变化。
     * 这一步在配方之后执行，只碰 LAYER_INDEX 类型的属性，其它一概不理。
     *
     * 返回实际绑定的属性个数。
     */
    function bindLayers(effectGroup, layerIndex) {
        var bound = 0;
        var index = layerIndex || 2;

        function walk(group, depth) {
            if (depth > 2) return;
            var count = 0;
            try {
                count = group.numProperties;
            } catch (e) {
                return;
            }
            for (var i = 1; i <= count; i++) {
                var prop = null;
                try {
                    prop = group.property(i);
                } catch (e2) {
                    continue;
                }
                if (!prop) continue;

                var childCount = 0;
                try {
                    childCount = prop.numProperties;
                } catch (e3) {
                    childCount = 0;
                }
                if (childCount && childCount > 0) {
                    walk(prop, depth + 1);
                    continue;
                }
                if (!isLayerIndexProp(prop)) continue;
                try {
                    prop.setValue(index);
                    bound++;
                } catch (e4) {}
            }
        }

        walk(effectGroup, 0);
        return bound;
    }

    return {
        RECIPE_VERSION: RECIPE_VERSION,
        isNoPreview: isNoPreview,
        sceneFor: sceneFor,
        layoutFor: layoutFor,
        assetKindFor: assetKindFor,
        bindLayers: bindLayers,
        cacheKey: cacheKey,
        hashString: hashString,
        presentationTime: presentationTime,
        heuristicValue: heuristicValue,
        applyRecipe: applyRecipe,
        applyHeuristics: applyHeuristics,
        animate: animate,
        animateAny: animateAny,
        apply: apply,
        recipes: RECIPES,
        effectNameFor: effectNameFor,
        stepsFor: stepsFor,
        isSurrogate: isSurrogate
    };
})();
